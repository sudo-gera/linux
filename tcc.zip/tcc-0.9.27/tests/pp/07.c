#define a() YES
#define b() a
b()
b()()
